// usage: node cssguard.mjs [pagesDir]   (run through PowerShell with $env:TZ set for the time-zone runs)
// Round 13U (round-13s-scoping.md S4.5, round-13t-notes.md N7.2; suite-only, nothing in office-os changes): the one check
// that reads the live css as a whole. Every round's "no css changed" pin used to read it too, so any css edit tripped
// them all; they now read their result from the frozen css-pre13U, and an unintended css change is caught here instead.
//   B  the baseline;  C  the live css against it;  M  no scope pin reads the live css again
// A round that edits css on purpose: freeze its result as css-preNN, point BASELINE at it, and name its changes in its
// own suite. That line (and B1's count, if a file is added or removed) is the whole cost here. No clock, no jsdom, no
// storage: nothing here depends on the zone.
import fs from "fs";
import path from "path";

const HERE = path.dirname(new URL(import.meta.url).pathname.replace(/^\/(\w:)/, "$1"));
const DIR = process.argv[2] ?? path.join(HERE, "..", "w", "pages");
const BASELINE = "css-prelo";   // Round Small leftovers' css; css-precp is office-os bb9d29a's, and smallleft.mjs K1 and M4 name what Small leftovers changed
const LIVE = path.join(DIR, "..", "assets", "css"), BASE = path.join(HERE, BASELINE);

let passed = 0, failed = 0;
const check = (id, label, ok, detail = "") => { console.log(`${ok ? "PASS" : "FAIL"}  ${id.padEnd(5)} ${label}${detail !== "" ? `  -> ${detail}` : ""}`); ok ? passed++ : failed++; };
const section = (s) => console.log(`\n--- ${s} ---`);
const j = JSON.stringify;
const walk = (dir) => fs.readdirSync(dir, { recursive: true, withFileTypes: true }).filter((e) => e.isFile())
  .map((e) => path.relative(dir, path.join(e.parentPath ?? e.path, e.name)).replace(/\\/g, "/")).sort();
const bytes = (dir, f) => fs.readFileSync(path.join(dir, f));

// =================================================================
section("B. The baseline");
const base = walk(BASE);
check("B1", "the baseline holds the stylesheet set: 40 files, style.css and base/tokens.css among them (an empty folder would pass C1-C3 by itself)",
  base.length === 40 && base.includes("style.css") && base.includes("base/tokens.css"), base.length);

// =================================================================
section("C. The live css, byte for byte");
const live = fs.existsSync(LIVE) ? walk(LIVE) : null;
check("C0", "the live css folder exists and isn't empty", !!live && live.length > 0, live ? live.length : "missing");
const now = live ?? [];
const changed = now.filter((f) => base.includes(f) && !bytes(LIVE, f).equals(bytes(BASE, f)));
check("C1", "no css file changed", changed.length === 0, j(changed));
const added = now.filter((f) => !base.includes(f));
check("C2", "no css file added", added.length === 0, j(added));
const removed = base.filter((f) => !now.includes(f));
check("C3", "no css file removed", removed.length === 0, j(removed));

// =================================================================
section("M. No scope pin reads the live css again");
// A suite may read a rule the app depends on (READERS, each named for what it reads). Anything else that opens the live
// css is a new "no css changed" pin: compare frozen copies instead, as every round's X2 now does. Line comments don't count.
const READERS = {
  "appearance.mjs": "13X's accent block, role colours, print and avatar rules, and the menu's css",
  "backlog.mjs": "inventory.css's value-bars rule, responsive.css's stacking rule, and both files' line endings",
  "cleanup.mjs": "table.css's table--fit and form.css's data-missing hint",
  "cssguard.mjs": "this check",
  "dots.mjs": "dashboard.css's muted dot",
  "honest.mjs": "13Z's bell dot and search results rules in shell.css",
  "invpages.mjs": "inventory.css's line endings",
  "legend.mjs": "calendar.css's future look",
  "noflash.mjs": "14B's hiding rule in shell.css",
  "rail.mjs": "14C's rail.css, the tokens it adds, and the import order",
  "phone.mjs": "14D's phone.css, the responsive.css line, and the import order",
  "findsort.mjs": "14H's sort and search rules in phone.css, and responsive.css's hidden box",
  "shell.mjs": "13W's phone, form, tab and bar rules, and the sidebar colour",
  "view.mjs": "attendance.css's outline badges",
};
const LIVE_CSS = /assets\/css|"assets",\s*"css"/;
const uncomment = (s) => s.split(/\r?\n/).filter((l) => !/^\s*\/\//.test(l)).join("\n");
const suites = fs.readdirSync(HERE).filter((f) => f.endsWith(".mjs"));
const readers = suites.filter((f) => LIVE_CSS.test(uncomment(fs.readFileSync(path.join(HERE, f), "utf8")))).sort();
check("M1", "the only suites naming the live css are the named rule readers", j(readers) === j(Object.keys(READERS).sort()), j(readers.filter((f) => !READERS[f])));
check("M2", "every named reader still reads it (a stale entry would hide a new pin)", Object.keys(READERS).every((f) => readers.includes(f)), j(Object.keys(READERS).filter((f) => !readers.includes(f))));

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
