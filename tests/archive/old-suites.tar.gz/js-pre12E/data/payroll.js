// data/payroll.js
// The pay rules, as numbers and pure functions: how a monthly gross splits
// into earnings, the PF / professional tax / income tax (TDS) deductions, and
// how loss-of-pay days reduce a month's gross. Nothing here reads storage or
// the clock; data/payroll-store.js gathers each person's salary, attendance
// and leave and calls these.
//
// All amounts are whole rupees a month unless a name says annual.

// ---------- earnings and statutory deductions ----------

export const PAY_RULES = {
  basicShare: 0.40,          // basic = 40% of gross
  hraShareOfBasic: 0.50,     // HRA = 50% of basic
  conveyance: 1600,          // fixed a month (less only if gross can't cover it)
  pfShareOfBasic: 0.12,      // employee PF = 12% of basic (no wage ceiling); the employer pays the same
  professionalTax: 200,      // fixed a month (one state's sample figure; it really depends on the state)
};

const pct = (share) => `${Math.round(share * 100)}%`;

// The components as salary-structure.html lists them. `formula` is display text
// built from PAY_RULES, so the words and the arithmetic can't drift apart.
export const SALARY_COMPONENTS = [
  { key: "basic",      name: "Basic salary",         type: "earning",   formula: `${pct(PAY_RULES.basicShare)} of gross`,           taxable: true },
  { key: "hra",        name: "House rent allowance", type: "earning",   formula: `${pct(PAY_RULES.hraShareOfBasic)} of basic`,      taxable: "partly" },
  { key: "conveyance", name: "Conveyance allowance", type: "earning",   formula: `fixed ${PAY_RULES.conveyance}`,                    taxable: false },
  { key: "special",    name: "Special allowance",    type: "earning",   formula: "remainder of gross",                              taxable: true },
  { key: "pf",         name: "Provident fund",       type: "deduction", formula: `${pct(PAY_RULES.pfShareOfBasic)} of basic`,       taxable: null },
  { key: "pt",         name: "Professional tax",     type: "deduction", formula: `fixed ${PAY_RULES.professionalTax}`,               taxable: null },
  { key: "tds",        name: "Income tax (TDS)",     type: "deduction", formula: "slab-based, sample tax rates",                    taxable: null },   // TAX_SAMPLE, below
];

// gross -> { basic, hra, conveyance, special }, whole rupees that always add up
// to gross: special takes whatever is left after rounding.
export function splitGross(gross) {
  const g = Math.max(0, Math.round(gross));
  const basic = Math.round(g * PAY_RULES.basicShare);
  const hra = Math.round(basic * PAY_RULES.hraShareOfBasic);
  const conveyance = Math.min(PAY_RULES.conveyance, g - basic - hra);
  return { basic, hra, conveyance, special: g - basic - hra - conveyance };
}

export const providentFund = (basic) => Math.round(basic * PAY_RULES.pfShareOfBasic);
export const professionalTax = (gross) => (gross > 0 ? PAY_RULES.professionalTax : 0);

// ---------- income tax (TDS) ----------

// SAMPLE VALUES, copied from the slab table on finance/tax-deductions.html, which
// says the same: "sample values for the design. When the real app is built, use
// the current government rates." Not current tax law. New regime only; no cess,
// no surcharge, no marginal relief, no old regime.
export const TAX_SAMPLE = {
  standardDeduction: 75000,   // annual
  rebateLimit: 1200000,       // taxable income up to this pays no tax at all
  slabs: [                    // annual taxable income up to `upTo` (null = no limit) at `rate`
    { upTo: 400000, rate: 0 },
    { upTo: 800000, rate: 0.05 },
    { upTo: 1200000, rate: 0.10 },
    { upTo: 1600000, rate: 0.15 },
    { upTo: 2000000, rate: 0.20 },
    { upTo: 2400000, rate: 0.25 },
    { upTo: null, rate: 0.30 },
  ],
};

// Annual taxable income (after the standard deduction) -> annual tax, in rupees
// (may have paise). Zero at or under the rebate limit.
export function annualTax(taxable) {
  if (!(taxable > TAX_SAMPLE.rebateLimit)) return 0;
  let tax = 0;
  let from = 0;
  for (const { upTo, rate } of TAX_SAMPLE.slabs) {
    const top = upTo ?? Infinity;
    if (taxable > from) tax += (Math.min(taxable, top) - from) * rate;
    from = top;
  }
  return tax;
}

// The monthly TDS for a monthly gross: that gross for 12 months, less the
// standard deduction, through the slabs, spread evenly over 12 months.
export function monthlyTds(monthlyGross) {
  const taxable = Math.max(0, monthlyGross * 12 - TAX_SAMPLE.standardDeduction);
  return Math.round(annualTax(taxable) / 12);
}

// ---------- filing deadlines ----------

// SAMPLE VALUES, like TAX_SAMPLE: the rules behind the dates on
// finance/tax-deductions.html. A month's TDS is deposited by the 7th of the
// next month and its PF by the 15th; professional tax by the month's last day
// (it really depends on the state). The quarterly TDS return is due on the
// last day of the month after the quarter, except January to March's, due on
// 31 May. Quarters follow the financial year: Apr-Jun, Jul-Sep, Oct-Dec, Jan-Mar.
export const FILING_SAMPLE = { tdsDepositDay: 7, pfDay: 15, marchQuarterReturn: { month: 5, day: 31 } };

const two = (n) => String(n).padStart(2, "0");
const leap = (year) => (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
const lastDay = (year, month) => (month === 2 ? (leap(year) ? 29 : 28) : [4, 6, 9, 11].includes(month) ? 30 : 31);
const nextMonth = (year, month) => (month === 12 ? [year + 1, 1] : [year, month + 1]);

// The TDS return for the quarter a month is in: { year, from, to } (the
// quarter's first and last month, `year` being its last month's) and due
// ("YYYY-MM-DD").
export function tdsReturn(year, month) {
  const to = Math.ceil(month / 3) * 3;
  const [dy, dm] = to === 3 ? [year, FILING_SAMPLE.marchQuarterReturn.month] : nextMonth(year, to);
  const day = to === 3 ? FILING_SAMPLE.marchQuarterReturn.day : lastDay(dy, dm);
  return { year, from: to - 2, to, due: `${dy}-${two(dm)}-${two(day)}` };
}

// A month's deadlines, "YYYY-MM-DD": TDS deposit, PF, professional tax.
export function filingDates(year, month) {
  const [ny, nm] = nextMonth(year, month);
  return {
    tds: `${ny}-${two(nm)}-${two(FILING_SAMPLE.tdsDepositDay)}`,
    pf: `${ny}-${two(nm)}-${two(FILING_SAMPLE.pfDay)}`,
    pt: `${year}-${two(month)}-${two(lastDay(year, month))}`,
  };
}

// ---------- loss of pay ----------

// Loss-of-pay days for a month: each late-mark penalty half day is 0.5, each
// unpaid leave day 1 (a half day 0.5), each settled unexplained absence 1 (0.5
// when half-day leave covers the other half), each working day after a
// leaver's last one 1 (round 11Y: the final month is prorated), each working
// day before a joiner's joining date 1 (round 12D: so is the first month),
// never more than the month's working days. data/payroll-store.js decides
// which absences are settled.
export function lossOfPayDays({ penaltyHalfDays = 0, unpaidLeaveDays = 0, absenceDays = 0, leftDays = 0, notJoinedDays = 0, workingDays = 0 } = {}) {
  return Math.min(workingDays, penaltyHalfDays * 0.5 + unpaidLeaveDays + absenceDays + leftDays + notJoinedDays);
}

// The rupees a month's gross loses: gross / working days for each LOP day.
export function lossOfPayAmount(monthlyGross, lopDays, workingDays) {
  if (!(workingDays > 0) || !(lopDays > 0)) return 0;
  return Math.round((monthlyGross * Math.min(lopDays, workingDays)) / workingDays);
}

// ---------- one person's month ----------

// Everything a payslip needs from a monthly gross and that month's LOP inputs.
// The earnings and PF are worked out on the gross actually paid (after LOP);
// TDS on the full monthly gross. Professional tax and TDS are both capped so
// net pay never goes below zero (PT's cap since round 11N: a paid gross under
// about ₹214 used to leave net negative, 10U U4a).
// lop.leftDays is there only for a leaver's final month (round 11Y), and
// lop.notJoinedDays only for a joiner's first (round 12D).
export function computePay(monthlyGross, { penaltyHalfDays = 0, unpaidLeaveDays = 0, absenceDays = 0, leftDays = 0, notJoinedDays = 0, workingDays = 0 } = {}) {
  const lopDays = lossOfPayDays({ penaltyHalfDays, unpaidLeaveDays, absenceDays, leftDays, notJoinedDays, workingDays });
  const lopAmount = lossOfPayAmount(monthlyGross, lopDays, workingDays);
  const gross = monthlyGross - lopAmount;
  const earnings = splitGross(gross);
  const pf = providentFund(earnings.basic);
  const pt = Math.min(professionalTax(gross), gross - pf);
  const tds = Math.min(monthlyTds(monthlyGross), Math.max(0, gross - pf - pt));
  const deductions = pf + pt + tds;
  return {
    monthlyGross,
    workingDays,
    lop: { penaltyHalfDays, unpaidLeaveDays, absenceDays, ...(leftDays ? { leftDays } : {}), ...(notJoinedDays ? { notJoinedDays } : {}), days: lopDays, amount: lopAmount },
    gross,
    earnings,
    deductionLines: { pf, pt, tds },
    deductions,
    net: gross - deductions,
    employerPf: pf,
  };
}