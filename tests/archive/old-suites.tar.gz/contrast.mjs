// usage: node contrast.mjs [pagesDir]   (pagesDir unused: this suite reads only its frozen css, css-precp)
// Round Contrast pass: the pairs this round fixed, and the ones it left for a ruling, computed from the frozen tokens (css-precp/base/tokens.css)
// with the same arithmetic the browser uses for color-mix (srgb) and alpha; WCAG contrast; failing below 4.5 (text) or 3 (control boundaries, the
// rail's active fill). Light and dark, and the accents and roles that failed.
//   K  the tokens themselves (the values this round set)   F  the fixed pairs   L  the left pairs (no margin: still at least the threshold)
//   O  the dark overlay   W  the css rules that use the new tokens (frozen copies)
import fs from "fs";
import path from "path";
const HERE = path.dirname(new URL(import.meta.url).pathname.replace(/^\/(\w:)/, "$1"));
const read = (...p) => fs.readFileSync(path.join(HERE, "css-precp", ...p), "utf8");
let passed = 0, failed = 0;
const check = (n, label, cond, detail = "") => { cond ? passed++ : failed++; console.log(`${cond ? "PASS" : "FAIL"}  ${String(n).padEnd(5)} ${label}${detail !== "" ? `  -> ${detail}` : ""}`); };
const section = (t) => console.log(`\n--- ${t} ---`);
const j = JSON.stringify;
const TOK = read("base", "tokens.css");
// the value a token has in :root, or in a block (dark, a role, an accent)
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const block = (sel) => { const m = new RegExp(`${esc(sel)}\\s*\\{`).exec(TOK); if (!m) return ""; return TOK.slice(m.index, TOK.indexOf("}", m.index)); };   // "[data-accent="blue"]   {" too
const tok = (name, ...blocks) => { for (const b of [...blocks, ":root"]) { const m = new RegExp(`--${name}:\\s*([^;]+);`).exec(block(b)); if (m) return m[1].trim(); } return null; };
const hex2 = (h) => ({ r: parseInt(h.slice(1, 3), 16), g: parseInt(h.slice(3, 5), 16), b: parseInt(h.slice(5, 7), 16) });
const toHex = (c) => "#" + [c.r, c.g, c.b].map((v) => Math.round(v).toString(16).padStart(2, "0")).join("");
const mix = (a, b, p) => { const x = hex2(a), y = hex2(b); return toHex({ r: x.r * p + y.r * (1 - p), g: x.g * p + y.g * (1 - p), b: x.b * p + y.b * (1 - p) }); };   // p of a, as color-mix(in srgb)
const lum = ({ r, g, b }) => [r, g, b].map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }).reduce((s, v, i) => s + v * [0.2126, 0.7152, 0.0722][i], 0);
const ratio = (a, b) => { const [x, y] = [lum(hex2(a)), lum(hex2(b))].sort((p, q) => q - p); return Math.round(((x + 0.05) / (y + 0.05)) * 100) / 100; };
const isHex = (v) => /^#[0-9a-f]{6}$/i.test(v ?? "");

const L = { surface: tok("color-surface"), bg: tok("color-bg"), hover: tok("color-surface-hover"), muted: tok("color-text-muted"), text: tok("color-text"), sidebar: tok("color-sidebar"), sidebarText: tok("color-sidebar-text") };
const D = { surface: tok("color-surface", '[data-theme="dark"]'), bg: tok("color-bg", '[data-theme="dark"]'), hover: tok("color-surface-hover", '[data-theme="dark"]'), sidebar: tok("color-sidebar", '[data-theme="dark"]') };
const control = { light: tok("color-border-control"), dark: tok("color-border-control", '[data-theme="dark"]') };
const ROLE = { admin: tok("role-base", '[data-role="admin"]'), hr: tok("role-base", '[data-role="hr"]'), fin: tok("role-base", '[data-role="fin"]'), emp: tok("role-base", '[data-role="emp"]') };
const ACC = Object.fromEntries(["indigo", "blue", "teal", "violet", "slate", "pink"].map((a) => [a, tok("primary-base", `[data-accent="${a}"]`)]));
const CHIP = [1, 2, 3, 4].map((n) => tok(`chip-${n}`));

section("K. The tokens this round set");
check("K1", "--color-border-control: #85878a light, #6a7280 dark", control.light === "#85878a" && control.dark === "#6a7280", j(control));
check("K2", "the rail's active item: --color-rail-active is the primary 62% toward white (dark mode's own fill), --color-on-rail-active #0b1020",
  /--color-rail-active:\s*color-mix\(in srgb, var\(--primary-base\) 62%, #ffffff\);/.test(TOK) && tok("color-on-rail-active") === "#0b1020", tok("color-rail-active"));
check("K3", "blue (accent and the employee role) #245fe2; Finance's amber #aa4e09; the other primaries as they were", ACC.blue === "#245fe2" && ROLE.emp === "#245fe2" && ROLE.fin === "#aa4e09"
  && j([ACC.indigo, ACC.teal, ACC.violet, ACC.slate, ACC.pink, ROLE.admin, ROLE.hr]) === j(["#4f46e5", "#0f766e", "#6d28d9", "#475569", "#be185d", "#4f46e5", "#0f766e"]), j({ ACC, ROLE }));
check("K4", "the light chips: #2056cc, #046d4d, #904f04, and chip 4 as it was (#7c3aed, left for a ruling)", j(CHIP) === j(["#2056cc", "#046d4d", "#904f04", "#7c3aed"]), j(CHIP));

section("F. The pairs this round fixed");
const row = (pairs) => pairs.map(([fg, bg]) => `${fg} on ${bg} ${ratio(fg, bg)}`).join("; ");
const all = (pairs, need) => pairs.every(([fg, bg]) => isHex(fg) && isHex(bg) && ratio(fg, bg) >= need);
const FIELD = [[control.light, L.surface], [control.light, L.bg], [control.light, L.hover], [control.dark, D.surface], [control.dark, D.bg], [control.dark, D.hover]];
check("F1", "a form control's edge (field, checkbox, unchecked switch, topbar search box) at least 3.2:1 (3 plus the margin) on the surface, the page and a hovered row, light and dark", all(FIELD, 3.2), row(FIELD));
const PRIMS = { ...ACC, fin: ROLE.fin };
const RAIL = Object.entries(PRIMS).map(([k, c]) => [mix(c, "#ffffff", 0.62), L.sidebar, k]);
check("F2", "the rail's active fill at least 3:1 on the navy rail for all 7 primaries, and its icon or count (#0b1020) at least 4.5:1 on the fill",
  RAIL.every(([f, s]) => ratio(f, s) >= 3 && ratio("#0b1020", f) >= 4.5), RAIL.map(([f, s, k]) => `${k} ${f} ${ratio(f, s)} / icon ${ratio("#0b1020", f)}`).join("; "));
const AV = CHIP.slice(0, 3).map((c) => [c, mix(c, L.surface, 0.14)]);
check("F3", "avatar initials, chips 1-3, at least 4.5:1 on their 14% tints (light)", all(AV, 4.5), row(AV));
const SOFT = [[ACC.blue, mix(ACC.blue, L.surface, 0.11)], [ROLE.fin, mix(ROLE.fin, L.surface, 0.11)]];
check("F4", "blue and Finance's amber at least 4.5:1 on their own soft fills (11%; 13X's 4.44 and the 4.32)", all(SOFT, 4.5), row(SOFT));
const NOTES = Object.values(PRIMS).map((c) => [L.text, mix(c, L.surface, 0.11)]);
check("F5", "a chosen option's note and the net-pay label (the text colour) on every primary's soft fill", all(NOTES, 4.5), row(NOTES.slice(0, 3)) + "; …");
check("F6", "the login panel's small print (--color-sidebar-text) on the navy panel, light and dark", ratio(L.sidebarText, L.sidebar) >= 4.5 && ratio(L.sidebarText, D.sidebar) >= 4.5, `${ratio(L.sidebarText, L.sidebar)} / ${ratio(L.sidebarText, D.sidebar)}`);
check("F7", "a past date tile's month (the text colour at the tile's 0.7) on the surface, light", ratio(mix(L.text, L.surface, 0.7), L.surface) >= 4.5, ratio(mix(L.text, L.surface, 0.7), L.surface));
check("F8", "the topbar search placeholder (muted) on the page, light", ratio(L.muted, L.bg) >= 4.5, ratio(L.muted, L.bg));

section("L. Left for a ruling (no margin): still at least the threshold");
check("L1", "muted on the page #667085 on #f6f7f9 (breadcrumbs, subtitles, table heads, .reason)", ratio(L.muted, L.bg) >= 4.5 && L.muted === "#667085", ratio(L.muted, L.bg));
check("L2", "muted on a grey fill #667085 on #f2f4f7 (Ctrl K, tab counts, badges)", ratio(L.muted, L.hover) >= 4.5, ratio(L.muted, L.hover));
check("L3", "avatar initials, chip 4, on its tint", ratio(CHIP[3], mix(CHIP[3], L.surface, 0.14)) >= 4.5, ratio(CHIP[3], mix(CHIP[3], L.surface, 0.14)));

section("O. The dark overlay");
check("O1", "dark --overlay rgba(0, 0, 0, 0.6); light as it was, rgba(16, 24, 40, 0.5)", tok("overlay", '[data-theme="dark"]') === "rgba(0, 0, 0, 0.6)" && /:root[\s\S]*--overlay: rgba\(16, 24, 40, 0\.5\);/.test(block(":root")), `${tok("overlay")} / ${tok("overlay", '[data-theme="dark"]')}`);

section("W. The rules that use them (frozen css)");
const FORM = read("components", "form.css"), RAILCSS = read("layout", "rail.css"), SHELL = read("layout", "shell.css"), AUTH = read("pages", "auth.css"), ATT = read("pages", "attendance.css"), PAY = read("pages", "payroll.css");
check("W1", "fields, checkbox and the unchecked switch take --color-border-control (form.css: 4 uses), the topbar search box and the OTP fields too",
  (FORM.match(/var\(--color-border-control\)/g) ?? []).length === 4 && /\.topbar__search \{[^}]*border: 1px solid var\(--color-border-control\)/.test(SHELL) && /\.otp__input \{[^}]*border: 1px solid var\(--color-border-control\)/.test(AUTH),
  (FORM.match(/var\(--color-border-control\)/g) ?? []).length);
check("W2", "the rail's active item and its count take the rail tokens", /background: var\(--color-rail-active\); color: var\(--color-on-rail-active\);/.test(RAILCSS) && /\.nav__item\.is-active \.nav__count \{ color: var\(--color-on-rail-active\); \}/.test(RAILCSS));
check("W3", "the placeholder, the small print, the date tile, the chosen note and the net-pay label rules", /\.topbar__search input::placeholder \{ color: var\(--color-text-muted\); \}/.test(SHELL) && /\.auth__copy \{ color: var\(--color-sidebar-text\);/.test(AUTH)
  && /\.date-tile--muted \.date-tile__month \{ color: var\(--color-text\); \}/.test(ATT) && /\.choice:has\(input:checked\) \.choice__meta \{ color: var\(--color-text\); \}/.test(ATT) && /\.payslip__net > div > span \{ color: var\(--color-text\); \}/.test(PAY)
  && /\.payslip__net span \{ display: block; font-size: var\(--text-sm\); color: var\(--color-text-muted\); \}/.test(PAY));
console.log(`\n${passed} passed, ${failed} failed`);
